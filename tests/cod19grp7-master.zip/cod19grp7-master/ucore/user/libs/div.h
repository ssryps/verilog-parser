//
// Created by Fan Qu on 12/4/19.
//

#ifndef SNAKE_DIV_H
#define SNAKE_DIV_H


//software divu, use 2 base div
unsigned int modm(unsigned int x, unsigned int m);
unsigned int divm(unsigned int x, unsigned int m);

#endif //SNAKE_DIV_H
