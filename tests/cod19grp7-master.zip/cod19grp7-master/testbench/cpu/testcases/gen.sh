make clean
python generate_cases.py instructions
make